const squirtles = require("./squirtles.json");
