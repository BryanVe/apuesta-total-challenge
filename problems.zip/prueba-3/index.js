async function slowFunction(num) {
  await new Promise((resolve) => setTimeout(resolve, 2000));
  return num;
}
